// ==========================
// server.js
// Sincroniza móvil ↔ escritorio
// ==========================
const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

// Servir archivos estáticos desde "public"
app.use(express.static(path.join(__dirname, 'public')));

// Rutas para desktop y móvil
app.get('/desktop', (req, res) => {
res.sendFile(path.join(__dirname, 'public/desktop.html'));
});

app.get('/mobile', (req, res) => {
res.sendFile(path.join(__dirname, 'public/mobile.html'));
});

// --- Conexión con socket.io ---
io.on('connection', (socket) => {
console.log('✅ Nuevo cliente conectado:', socket.id);

  // Recibir datos de toque desde el móvil y reenviar al escritorio
socket.on('touch', (data) => {
    console.log('Datos recibidos del móvil:', data);
    io.emit('touch', data); // Reenvía el toque a TODOS los clientes conectados
});

socket.on('disconnect', () => {
    console.log('❌ Cliente desconectado:', socket.id);
});
});

// Iniciar servidor
const PORT = 3000;
server.listen(PORT, () => {
console.log(`Servidor corriendo en: http://localhost:${PORT}`);
});