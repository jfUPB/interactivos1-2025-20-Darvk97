// ==========================
// Cliente escritorio: Visualización musical reactiva
// ==========================
let socket;
let cancion;
let fft;
let puntos = [];
let gifImg;

function preload() {
  gifImg = loadImage('spooky.gif');
  cancion = loadSound('slam.mp3');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(0);

  // Conectar al servidor
  socket = io.connect();

  // Reanudar audio tras interacción
  userStartAudio();

  // Música de fondo
  if (cancion && !cancion.isPlaying()) {
    cancion.loop();
  }

  fft = new p5.FFT();

  // Recibir coordenadas del móvil y guardarlas
  socket.on("touch", (data) => {
    let x = data.x * width;
    let y = data.y * height;
    puntos.push({ x, y, tiempo: millis() });
  });
}

function draw() {
  background(0, 20); // leve rastro

  let spectrum = fft.analyze();
  let bass = fft.getEnergy("bass");

  // Cambia el color del tint según la música
  let brillo = map(bass, 0, 255, 50, 255);

  // Dibujar todas las posiciones recibidas del móvil
  for (let p of puntos) {
    push();
    tint(brillo, 255, 255, 200); // cambia la intensidad con el bajo
    image(gifImg, p.x - gifImg.width / 4, p.y - gifImg.height / 4, 100, 100);
    pop();
  }

  // Eliminar puntos viejos (para que desaparezcan)
  puntos = puntos.filter(p => millis() - p.tiempo < 2000);
}