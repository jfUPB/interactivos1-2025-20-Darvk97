// ==========================
// Cliente móvil: Envío de toques al escritorio
// ==========================
let socket;
let img;

function preload() {
  // Carga una imagen de fondo opcional (puedes quitarla si no la necesitas)
  img = loadImage('WhatsApp Image 2025-10-21 at 6.57.07 PM.jpeg');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(0);
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(22);
  text("Toca y mueve el dedo ", width / 2, height / 2);

  // Conexión con el servidor
  socket = io.connect();
}

function touchMoved() {
  // Normalizamos las coordenadas (0–1) para adaptarlas al tamaño del escritorio
  let touchData = {
    x: mouseX / width,
    y: mouseY / height
  };

  // Enviar las coordenadas al servidor
  socket.emit("touch", touchData);

  // Mostrar una pequeña estela local (efecto visual)
  noStroke();
  fill(random(200, 255), random(100, 255), random(200, 255), 150);
  ellipse(mouseX, mouseY, 25, 25);

  return false; // Previene scroll en móvil
}